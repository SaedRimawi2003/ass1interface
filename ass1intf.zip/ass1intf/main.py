from __future__ import annotations

import time

from  ass1.api import COLORS, Mouse
from  ass1.astar import AStar
from  ass1.bfs import BFS
from  ass1.dfs import DFS
from  ass1.floodfill import FloodFill
from  ass1.lefthand import LeftHand  # Corrected import for LeftHand class





def lefthand():
    mouse = Mouse()
    lefthand_solver = LeftHand(mouse)  # Instantiate the LeftHand class

    # Run the Left-Hand Rule algorithm with debugging enabled
    path = lefthand_solver.run(debug=True)
    print("Path taken:", path)


def floodfill():
    flood = FloodFill(mouse=Mouse())
    flood.log(f"Starting at {flood.current}")
    counter = 0
    while True:
        if counter == 6:
            break
        start = time.perf_counter()
        flood.run(debug=True)
        flood.log(f"Took {time.perf_counter() - start} seconds")
        for i in flood.flood:
            flood.log(i)
        flood.reset(manual=False)
        counter += 1
    flood.log(flood.paths)
    path = flood.paths[min(flood.paths.keys())]
    flood.log(f"Running optimized path of length {len(path)}")
    start = time.perf_counter()
    flood.reset(manual=True)
    for step in path:
        flood.move(step)
        flood.mouse.set_color(*step, COLORS.DARK_RED)

    flood.log(f"Took {time.perf_counter() - start} seconds")


def astar():
    astar = AStar(mouse=Mouse())
    astar.log(f"Starting at {astar.current}")
    start = time.perf_counter()
    path = astar.run(debug=True)
    astar.log(f"Took {time.perf_counter() - start} seconds")
    astar.log(f"Running optimized path of length {len(path)}")
    astar.reset()
    start = time.perf_counter()
    for point in path:
        astar.move(point)
        astar.mouse.set_color(*point, COLORS.DARK_BLUE)
    astar.log(f"Took {time.perf_counter() - start} seconds")


def bfs():
    bfs = BFS(mouse=Mouse())
    bfs.log(f"Starting at {bfs.current}")
    start = time.perf_counter()
    path = bfs.run(debug=True)
    bfs.log(f"Took {time.perf_counter() - start} seconds")
    bfs.log(f"Running optimized path of length {len(path)}")
    bfs.reset()
    start = time.perf_counter()
    for point in path:
        bfs.move(point)
        bfs.mouse.set_color(*point, COLORS.DARK_GREEN)
    bfs.log(f"Took {time.perf_counter() - start} seconds")


def dfs():
    dfs = DFS(mouse=Mouse())
    dfs.log(f"Starting at {dfs.current}")
    start = time.perf_counter()
    path = dfs.run(debug=True)
    dfs.log(f"Took {time.perf_counter() - start} seconds")
    dfs.log(f"Running optimized path of length {len(path)}")
    dfs.reset()
    start = time.perf_counter()
    for point in path:
        dfs.move(point)
        dfs.mouse.set_color(*point, COLORS.DARK_CYAN)
    dfs.log(f"Took {time.perf_counter() - start} seconds")


def reset():
    mouse = Mouse()
    mouse.ack_reset()
    mouse.clear_all_color()


def main():

   
    floodfill()
    reset()
    astar()
    reset()
    bfs()
    reset()
    dfs()
    reset()
    lefthand()
    
   

if __name__ == "__main__":
    main()
